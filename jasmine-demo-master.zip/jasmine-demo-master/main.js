// const fibonacci = require('./lib/fibonacci')
// console.log(fibonacci(1));
